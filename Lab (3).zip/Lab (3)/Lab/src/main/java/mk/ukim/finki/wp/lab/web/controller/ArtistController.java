package mk.ukim.finki.wp.lab.web.controller;


import org.springframework.stereotype.Controller;

@Controller
public class ArtistController {
}
