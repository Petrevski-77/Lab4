package mk.ukim.finki.wp.lab.service.Impl;

import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.repository.impl.ArtistRepositoryImpl;
import mk.ukim.finki.wp.lab.repository.impl.ArtistRepositoryImpl;
import mk.ukim.finki.wp.lab.repository.jpa.SongRepository;
import mk.ukim.finki.wp.lab.repository.impl.SongRepositoryImpl;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SongServiceImpl implements SongService {

    private final ArtistRepositoryImpl artistRepository;
    private final SongRepository songRepository;

    public SongServiceImpl(ArtistRepositoryImpl artistRepository, SongRepository songRepository) {
        this.artistRepository = artistRepository;
        this.songRepository = songRepository;
    }

    @Override
    public List<Song> listSongs() {
        return songRepository.findAll();
    }

    @Override
    public Artist addArtistToSong(Artist artist, Song song) {
        return songRepository.addArtistToSong(song, artist);
    }

    @Override
    public Song findByTrackId(Long trackId) {
        return songRepository.findByTrackId(String.valueOf(trackId));
    }

    @Override
    public Optional<Song> save(String title, String genre, Integer releaseYear, Album album) {
        return Optional.of(songRepository.save(new Song(title, genre, releaseYear, album)));
    }

    @Override
    public void deleteById(Long id) {
        this.songRepository.deleteById(id);
    }

}
