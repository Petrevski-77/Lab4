package mk.ukim.finki.wp.lab.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@NoArgsConstructor
@Entity
@Getter
@Data
public class Song {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long trackId;
    String title;
    String genre;
    Integer releaseYear;
    @ManyToOne
    private Album album;
    @ManyToMany
    private List<Artist> performers;

    public Song(String title, String genre, int releaseYear, Album album) {
        this.trackId = (long) (Math.random() * 1000);
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.album = album;
        performers = new ArrayList<>();
    }

    public void addArtist(Artist performer) {
        performers.add(performer);
    }

    public List<Artist> getPerformers() {
        return performers;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public Long getTrackId() {
        return trackId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setTrackId(Long trackId) {
        this.trackId = trackId;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setReleaseYear(Integer releaseYear) {
        this.releaseYear = releaseYear;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

    public void setPerformers(List<Artist> performers) {
        this.performers = performers;
    }
}
